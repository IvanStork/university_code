/*
*objects.h
* contains the classes for each object
* authors: Ivan Ooijevaar & Marlin Sliman
*/
#include "GameObjectStruct.h"
#include<map>
#include "UI.h"
#include <string>
#include<iostream>
class Movers {//class for all things that move
  public:
    Movers(int, int);

    bool CanIMove( std::vector<std::vector<int>>, std::string);//initialize functions
    void move(std::string);
    int getCoordinates(std::string);
    void setCoordinates(int, int);
  private:
    std::string name;
    int x;
    int y;
};

class Pacman : public Movers{//pacman specific class
  public:
    Pacman(int, int);


    private:
    
};

class Ghosts : public Movers//ghosts start at positions 12, 13, 14, 15 on row 13
{
  public:
    Ghosts(int, int);
    std::string whichWay( std::vector<std::vector<int>>);
    private:
    std::string dirprev;
};

