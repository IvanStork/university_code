/*
*objects.h
* contains the classes for each object
* authors: Ivan Ooijevaar & Marlin Sliman
*/
#include "GameObjectStruct.h"
#include "UI.h"
#include <string>
#include<iostream>
class Movers {
  public:
    Movers();

    bool CanIMove(std::string&);

  private:
    std::string name;
};

class Pacman : public Movers{
  public:
    Pacman(int, int);


    private:
    int x;
      int y;
};

