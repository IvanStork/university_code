/*
*objects.h
* contains the classes for each object
* authors: Ivan Ooijevaar & Marlin Sliman
*/
#include "GameObjectStruct.h"
#include<map>
#include "UI.h"
#include <string>
#include<iostream>

class Game//class for all objects
{
  public:
    Game(int, int);

    int getCoordinates(std::string);
    void setCoordinates(int, int);
    GameObjectStruct getStruct();
    void setStruct(int, int, Type, Direction);
    void setType(Type);
    bool CanIMove(std::vector<std::vector<int>>,
                  std::string); 
    void move(std::string);

    private:
    int x;
      int y;
    GameObjectStruct object;
};



class Pacman : public Game{//pacman specific class
  public:
    Pacman(int, int, Type, Direction);


    private:
    
};

class Ghosts : public Game//ghosts start at positions 12, 13, 14, 15 on row 13
{
  public:
    Ghosts(int, int, Type, Direction);
     std::string whichWay( std::vector<std::vector<int>>);
    void setEat(bool);
     bool getEat();
    void setDirprev(std::string);
    std::string getDirprev();
    private:
    std::string dirprev;
      bool canBeEaten = false;
};

class Clyde : public Ghosts//tracking ghost
{
  public:
    Clyde(int, int, Type, Direction);
     std::string whichWay2(std::vector<std::vector<int>>, Pacman) ;//new movement version that tracks pacman
};

class Edibles : public Game
{
  public:
    Edibles(int, int, Type, Direction);

    private:
    int x;
      int y;
};
